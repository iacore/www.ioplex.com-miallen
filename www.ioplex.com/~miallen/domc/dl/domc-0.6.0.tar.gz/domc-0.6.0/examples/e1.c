#include <stdlib.h>
#include <stdio.h>
#include <domc.h>

void
event0_fn(DOM_Event *evt)
{
	DOM_Event *e2;

	MSG("event0_fn Fired! -- type=%s,target=%s,currentTarget=%s,eventPhase=%d,bubbles=%d", evt->type, evt->target->nodeName, evt->currentTarget->nodeName, evt->eventPhase, evt->bubbles);

	e2 = DOM_DocumentEvent_createEvent(evt->target->ownerDocument, "Events");
	DOM_Event_initEvent(e2, "Events", 1, 1);
	if (DOM_EventTarget_dispatchEvent(evt->target->parentNode, e2)) {
		MSG("e2 default prevented");
	}
}
void
event1_fn(DOM_Event *evt)
{
	MSG("event1_fn Fired! -- type=%s,target=%s,currentTarget=%s,eventPhase=%d,bubbles=%d", evt->type, evt->target->nodeName, evt->currentTarget->nodeName, evt->eventPhase, evt->bubbles);
}

int
main(int argc, char *argv[])
{
	DOM_Document *doc;
	DOM_Element *elem;
	DOM_Event *evt;

	if (argc < 2) {
		MSG("Must provide XML filename");
		return EXIT_FAILURE;
	}

	doc = DOM_Implementation_createDocument(NULL, NULL, NULL);
	if (DOM_DocumentLS_load(doc, argv[1]) == 0) {
		if (DOM_Exception) {
			MNF(DOM_Exception, " trying to load %s", argv[1]);
		}
		return EXIT_FAILURE;
	}

	elem = DOM_NodeList_item(DOM_Document_getElementsByTagName(doc, "three"), 0);
	DOM_EventTarget_addEventListener(elem, "Events", event0_fn, 0);
	DOM_EventTarget_addEventListener(elem->parentNode, "Events", event1_fn, 1);

	MSG("target[%s]", elem->parentNode->nodeName);

	evt = DOM_DocumentEvent_createEvent(doc, "Events");
	DOM_Event_initEvent(evt, "Events", 1, 1);
	if (DOM_EventTarget_dispatchEvent(elem, evt)) {
		MSG("default prevented");
	}

	DOM_Document_destroyNode(doc, doc);

	return EXIT_SUCCESS;
}
