#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <check.h>
#include <locale.h>
#define HAVE_VARMACRO 1
#include <mba/msgno.h>
#include <mba/linkedlist.h>
#include <domc.h>

#ifndef LOADBASE
#error LOADBASE not defined
#endif

#define assertEqualsInt(id, i1, i2)  _fail_unless((i1) == (i2), __FILE__, __LINE__, (id))
#define assertEqualsString(id, s1, s2)  _fail_unless(strcmp((s1), (s2)) == 0, __FILE__, __LINE__, (id))
#define assertEqualsList(id, l1, l2) _fail_unless(linkedlist_equals((l1), (l2)), __FILE__, __LINE__, (id))
#define assertSizeList(id, s, l) _fail_unless((s) == linkedlist_size(l), __FILE__, __LINE__, (id))
#define assertSize(id, s, l) _fail_unless(((s) == 0 && (l) == NULL) || (s) == (l)->length, __FILE__, __LINE__, (id))
#define equalsString(id, s1, s2) (strcmp((s1), (s2)) == 0)
#define assertURIEquals(id,n1,n2,n3,s1,n4,n5,n6,s2) _fail_unless(strcmp((s1), (s2)) == 0, __FILE__, __LINE__, (id))
#define null NULL

int
isIgnoringElementContentWhitespace(void)
{
	return 0;
}
int
isExpandEntityReferences(void)
{
	return 1;
}

int
linkedlist_equals(struct linkedlist *l1, struct linkedlist *l2)
{
	int idx, end;
	char *s1, *s2;

	mark_point();

	end = linkedlist_size(l1);
//MSG("l1=%u,l2=%u", end, linkedlist_size(l2));
	if (end != linkedlist_size(l2))
		return 0;

	for (idx = 0; idx < end; idx++) {
		s1 = linkedlist_get(l1, idx);
		s2 = linkedlist_get(l2, idx);

		if (s1 == NULL || s2 == NULL || strcmp(s1, s2))
			return 0;
	}

	return 1;
}

DOM_Document *
load(const char *filename)
{
	static char buf[2048];
	DOM_DocumentLS *doc;

	snprintf(buf, 2000, "%s/%s.xml", LOADBASE, filename);
	if ((doc = DOM_Implementation_createDocument(NULL, NULL, NULL)) == NULL ||
				DOM_DocumentLS_load(doc, buf) == 0) {
MSG("filename=%s", buf);
		fail("Cannot load file");
	}

/*
if ((doc = DOM_Node_cloneNode(doc, 1)) == NULL) {
	MSG("clone failed");
	return NULL;
}
*/

	return doc;
}

void
printAttrNames(DOM_NamedNodeMap *attributes)
{
	int i;

	putc('\n', stdout);
	for (i = 0; i < attributes->length; i++) {
		printf("attributes[%u]=\"%s\"\n", i, DOM_NamedNodeMap_item(attributes, i)->nodeName);
	}
}

#ifndef SINGLEH
#include "level1_tests.h"
#else
#include SINGLEH
#endif

Suite *
dom_level1_suite(void) 
{ 
	Suite *s = suite_create("Level1");
	TCase *tc_core = tcase_create("Core");
	suite_add_tcase(s, tc_core);

	DOM_Exception = 0;
#ifndef SINGLE
	#include "level1_add_tests.h"
#else
	tcase_add_test(tc_core, SINGLE);
#endif

	return s;
}

int
main(void)
{
	int nf;
	Suite *s = dom_level1_suite();
	SRunner *sr = srunner_create(s);

	if (!setlocale(LC_CTYPE, "")) {
			fprintf(stderr, "Can't set the specified locale! "
							"Check LANG, LC_CTYPE, LC_ALL.\n");
		return EXIT_FAILURE;
	}

	srunner_run_all(sr, CK_VERBOSE);
	nf = srunner_ntests_failed(sr);
	srunner_free(sr);
	suite_free(s);
	return (nf == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}

