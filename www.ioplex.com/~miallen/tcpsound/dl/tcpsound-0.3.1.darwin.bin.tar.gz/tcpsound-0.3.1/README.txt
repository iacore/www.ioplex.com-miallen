tcpsound
Play sounds in response to network traffic
http://www.ioplex.com/~miallen/tcpsound/

Mon Sep  5 03:04:02 EDT 2005
tcpsound-0.3.1 released

Small build bugfix.

Fri Apr 29 18:11:59 EDT 2005
tcpsound-0.3.0 released

Updated to build cleanly with libmba and created a binary package for
Mac OS X.

Wed May 26 00:42:13 EDT 2004
tcpsound-0.2.3 released

Some logic that tried to compensate for delays in SSH has been removed
as it did not live up to expectations.

Sat May 22 13:59:50 EDT 2004
tcpsound-0.2.2 released

Minor fixes and support for PROTO_ICMP.

Fri May 21 15:37:42 EDT 2004
tcpsound-0.2.0 released

Initial release.

--8<--

Any problems can be reported to the libmba mailing list.

If you're interested in developing this code more by all means go ahead. I
wrote this just for kicks while on vacay at dad's house at UIUC so it is
highly unlikely that I will develop it further (except for show-stopping
bugs perhaps).
