Good websites for sounds are:

  http://www.findsounds.com/
  http://www.vionline.com/sound.html
