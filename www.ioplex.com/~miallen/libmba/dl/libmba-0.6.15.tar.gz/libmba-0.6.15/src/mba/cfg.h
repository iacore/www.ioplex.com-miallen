#ifndef CFG_H
#define CFG_H

/* cfg - persistent configuration properties interface
 */

#include <stdio.h>
#include <mba/iterator.h>
#include <mba/text.h>

struct cfg;

struct cfg *cfg_new(void);
void cfg_del(void *this);

int cfg_load(struct cfg *this, const char *filename);
int cfg_load_str(struct cfg *this, const tchar *src, const tchar *slim);
int cfg_load_env(struct cfg *this);
int cfg_load_cgi_query_string(struct cfg *this, const tchar *qs);
int cfg_store(struct cfg *this, const char *filename);
int cfg_write(struct cfg *this, FILE *stream);

int cfg_get_str(struct cfg *this, tchar *dst, int dn, const tchar *def, const tchar *name);
int cfg_vget_str(struct cfg *this, tchar *dst, int dn, const tchar *def, const tchar *name, ...);
int cfg_get_short(struct cfg *this, short *dst, short def, const tchar *name);
int cfg_vget_short(struct cfg *this, short *dst, short def, const tchar *name, ...);
int cfg_get_int(struct cfg *this, int *dst, int def, const tchar *name);
int cfg_vget_int(struct cfg *this, int *dst, int def, const tchar *name, ...);
int cfg_get_long(struct cfg *this, long *dst, long def, const tchar *name);
int cfg_vget_long(struct cfg *this, long *dst, long def, const tchar *name, ...);
void cfg_iterate(void *cfg, iter_t *iter);
const tchar *cfg_next(void *cfg, iter_t *iter);

#endif /* CFG_H */

