#ifndef CSV_H
#define CSV_H

/* csv - read write comma separated value format
 */

#include <stdio.h>

int csv_row_parse(const char *src, size_t sn, char *buf, size_t bn, char *row[], int rn, int trim);
int csv_row_fread(FILE *in, char *buf, size_t bn, char *row[], int numcols, int trim);

#endif /* CSV_H */
