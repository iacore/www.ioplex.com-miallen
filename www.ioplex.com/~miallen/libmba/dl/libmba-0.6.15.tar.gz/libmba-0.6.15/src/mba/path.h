#ifndef PATH_H
#define PATH_H

/* path - manipulate file path names
 */

int path_canon(const unsigned char *src, const unsigned char *slim,
		unsigned char *dst, unsigned char *dlim, int sep);

#endif /* PATH_H */
