#ifndef POOL_H
#define POOL_H

/* pool - a container of recycleable objects
 */

#include <mba/iterator.h>

#define POOL_SIZE_MAX 2040

struct pool;
struct pool *pool_new(unsigned int max_size,
			void *(*new_data_fn)(void *), void *arg,
			void (*free_data_fn)(void *));
void pool_del(void *p);
void *pool_get(struct pool *p);
int pool_release(struct pool *p, void *data);
unsigned int pool_size(struct pool *p);
unsigned int pool_unused(struct pool *p);
void pool_iterate(void *p, iter_t *iter);
void *pool_next(void *p, iter_t *iter);

#endif /* POOL_H */

