#ifndef DOMNODE_H
#define DOMNODE_H

/* domnode - simple XML DOM-like interface
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <stdio.h>
#include <mba/text.h>

struct domnode {
	const tchar *name;
	const tchar *value;
	struct linkedlist *children;
	struct linkedlist *attrs;
};

LIBMBA_API struct domnode *domnode_new(const tchar *name, const tchar *value);
LIBMBA_API void domnode_del(void *this);

LIBMBA_API int domnode_load(struct domnode *this, const char *filename);
LIBMBA_API int domnode_store(struct domnode *this, const char *filename);
LIBMBA_API size_t domnode_read(struct domnode *this, FILE *stream);
LIBMBA_API size_t domnode_write(struct domnode *this, FILE *stream);

LIBMBA_API struct domnode *domnode_search(struct domnode *this, const tchar *name);

LIBMBA_API int domnode_attrs_put(struct linkedlist *attrs, struct domnode *attr);
LIBMBA_API struct domnode *domnode_attrs_get(struct linkedlist *attrs, const tchar *name);
LIBMBA_API struct domnode *domnode_attrs_remove(struct linkedlist *attrs, const tchar *name);

#ifdef __cplusplus
}
#endif

#endif /* DOMNODE_H */

