#ifndef LINKEDLIST_H
#define LINKEDLIST_H

/* linkedlist - a singularly linked list
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <mba/iterator.h>

struct linkedlist;

LIBMBA_API struct linkedlist *linkedlist_new(unsigned int);
LIBMBA_API void linkedlist_del(struct linkedlist *l, void (*free_data_fn)(void *));

LIBMBA_API void linkedlist_clear(struct linkedlist *l, void (*free_data_fn)(void *));
LIBMBA_API int linkedlist_add(struct linkedlist *l, void *data);
LIBMBA_API int linkedlist_insert(struct linkedlist *l, unsigned int idx, void *data);
LIBMBA_API int linkedlist_insert_sorted(struct linkedlist *l,
    int (*compar)(const void *, const void *), void **replaced, void *data);
LIBMBA_API int linkedlist_is_empty(const struct linkedlist *l);
LIBMBA_API unsigned int linkedlist_size(const struct linkedlist *l);
LIBMBA_API void *linkedlist_get(struct linkedlist *l, unsigned int idx);
LIBMBA_API void *linkedlist_get_last(const struct linkedlist *l);
LIBMBA_API void linkedlist_iterate(void *l, iter_t *iter);
LIBMBA_API void *linkedlist_next(void *l, iter_t *iter);
LIBMBA_API void *linkedlist_remove(struct linkedlist *l, unsigned int idx);
LIBMBA_API void *linkedlist_remove_last(struct linkedlist *l);
LIBMBA_API void *linkedlist_remove_data(struct linkedlist *l, void *data);
LIBMBA_API int linkedlist_toarray(struct linkedlist *l, void *array[]);

#ifdef __cplusplus
}
#endif

#endif /* LINKEDLIST_H */

