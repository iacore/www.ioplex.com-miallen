#ifndef VARRAY_H
#define VARRAY_H

/* varray - a variable sized array
 */ 

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <stddef.h>
#include <mba/iterator.h>

struct varray;

LIBMBA_API struct varray *varray_new(size_t membsize);
LIBMBA_API void varray_del(void *va);
LIBMBA_API void varray_release(struct varray *va, unsigned int from);
LIBMBA_API void *varray_get(struct varray *va, unsigned int idx);
LIBMBA_API void varray_iterate(void *va, iter_t *iter);
LIBMBA_API void *varray_next(void *va, iter_t *iter);

#ifdef __cplusplus
}
#endif

#endif /* VARRAY_H */
