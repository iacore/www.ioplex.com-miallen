#ifndef HASHMAP_H
#define HASHMAP_H

/* hashmap - a chaining hash map
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <mba/iterator.h>

#define HASHMAP_SMALL 17
#define HASHMAP_MEDIUM 701
#define HASHMAP_LARGE 8191

struct hashmap;

LIBMBA_API unsigned int hash_string(const void *);

LIBMBA_API struct hashmap *hashmap_new(unsigned int size,
				unsigned int (*hash_fn)(const void *),
				void (*free_key_fn)(void *),
				void (*free_data_fn)(void *));
LIBMBA_API void hashmap_del(struct hashmap *h);

LIBMBA_API int hashmap_put(struct hashmap *h, void *key, void *data);
LIBMBA_API int hashmap_is_empty(struct hashmap *h);
LIBMBA_API unsigned int hashmap_size(struct hashmap *h);
LIBMBA_API void *hashmap_get(const struct hashmap *h, const void *key);
LIBMBA_API void hashmap_iterate(void *h, iter_t *iter);
LIBMBA_API void *hashmap_next(void *h, iter_t *iter);
LIBMBA_API void *hashmap_remove(struct hashmap *h, const void *key);

#ifdef __cplusplus
}
#endif

#endif /* HASHMAP_H */

