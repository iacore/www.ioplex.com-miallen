#ifndef CFG_H
#define CFG_H

/* cfg - persistent configuration properties interface
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <stdio.h>
#include <mba/iterator.h>
#include <mba/text.h>

struct cfg;

LIBMBA_API struct cfg *cfg_new(void);
LIBMBA_API void cfg_del(void *this);

LIBMBA_API int cfg_load(struct cfg *this, const char *filename);
LIBMBA_API int cfg_load_str(struct cfg *this, const tchar *src, const tchar *slim);
LIBMBA_API int cfg_load_env(struct cfg *this);
LIBMBA_API int cfg_load_cgi_query_string(struct cfg *this, const tchar *qs);
LIBMBA_API int cfg_store(struct cfg *this, const char *filename);
LIBMBA_API int cfg_write(struct cfg *this, FILE *stream);

LIBMBA_API int cfg_get_str(struct cfg *this, tchar *dst, int dn, const tchar *def, const tchar *name);
LIBMBA_API int cfg_vget_str(struct cfg *this, tchar *dst, int dn, const tchar *def, const tchar *name, ...);
LIBMBA_API int cfg_get_short(struct cfg *this, short *dst, short def, const tchar *name);
LIBMBA_API int cfg_vget_short(struct cfg *this, short *dst, short def, const tchar *name, ...);
LIBMBA_API int cfg_get_int(struct cfg *this, int *dst, int def, const tchar *name);
LIBMBA_API int cfg_vget_int(struct cfg *this, int *dst, int def, const tchar *name, ...);
LIBMBA_API int cfg_get_long(struct cfg *this, long *dst, long def, const tchar *name);
LIBMBA_API int cfg_vget_long(struct cfg *this, long *dst, long def, const tchar *name, ...);
LIBMBA_API void cfg_iterate(void *cfg, iter_t *iter);
LIBMBA_API const tchar *cfg_next(void *cfg, iter_t *iter);

#ifdef __cplusplus
}
#endif

#endif /* CFG_H */

