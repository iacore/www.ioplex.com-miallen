#ifndef POOL_H
#define POOL_H

/* pool - a container of recycleable objects
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LIBMBA_API
#ifdef WIN32
# ifdef LIBMBA_EXPORTS
#  define LIBMBA_API  __declspec(dllexport)
# else /* LIBMBA_EXPORTS */
#  define LIBMBA_API  __declspec(dllimport)
# endif /* LIBMBA_EXPORTS */
#else /* WIN32 */
# define LIBMBA_API extern
#endif /* WIN32 */
#endif /* LIBMBA_API */

#include <mba/iterator.h>

#define POOL_SIZE_MAX 2040

struct pool;

LIBMBA_API struct pool *pool_new(unsigned int max_size,
			void *(*new_data_fn)(void *), void *arg,
			void (*free_data_fn)(void *));
LIBMBA_API void pool_del(void *p);
LIBMBA_API void *pool_get(struct pool *p);
LIBMBA_API int pool_release(struct pool *p, void *data);
LIBMBA_API unsigned int pool_size(struct pool *p);
LIBMBA_API unsigned int pool_unused(struct pool *p);
LIBMBA_API void pool_iterate(void *p, iter_t *iter);
LIBMBA_API void *pool_next(void *p, iter_t *iter);

#ifdef __cplusplus
}
#endif

#endif /* POOL_H */

