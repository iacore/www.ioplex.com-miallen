#include "common.h"
#include "mba/varray.h"

struct foo {
	int val;
	char c;
	unsigned long l;
};

int
VarrayOps(int verbose, struct cfg *cfg, char *args[])
{
	struct varray *va;
	struct foo *foo;
	iter_t iter;

	cfg = NULL; args[0] = NULL;

	if ((va = varray_new(sizeof(struct foo))) == NULL) {
		AMSG("");
		return -1;
	}

	foo = varray_get(va, 267);
	foo->val = 999;
	foo = varray_get(va, 50);
	foo->val = 55555;
	foo = varray_get(va, 15050);
	foo->l = 7777;
	varray_release(va, 300);

	varray_iterate(va, &iter);
	while ((foo = varray_next(va, &iter)) != NULL) {
		tcase_printf(verbose, " %d", foo->val);
		if (foo->val == 55555) {
			break;
		}
	}
	if (foo == NULL || foo->val != 55555) {
		return -1;
	}
	while ((foo = varray_next(va, &iter)) != NULL) {
		tcase_printf(verbose, " %d", foo->val);
		if (foo->val == 999) {
			break;
		}
	}
	if (foo == NULL || foo->val != 999) {
		return -1;
	}
	while ((foo = varray_next(va, &iter)) != NULL) {
		tcase_printf(verbose, " %d", foo->val);
		if (foo->val) {
			break;
		}
	}
	if (foo != NULL) {
		return -1;
	}

	varray_del(va);

	tcase_printf(verbose, "\ndone\n");

    return 0;
}
