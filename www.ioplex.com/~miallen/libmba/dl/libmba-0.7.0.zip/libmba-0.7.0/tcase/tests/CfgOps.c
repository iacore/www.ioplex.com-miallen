#include "common.h"
#include "mba/cfg.h"
#include "mba/text.h"

int
CfgOps(int verbose, struct cfg *cfg, char *args[])
{
	tchar *instr = TEXT("a=z\nc=d\n\ne=f");
	int i;

	cfg = cfg_new();
	if (cfg_load(cfg, args[0]) == -1) {
		AMSG("Failed to load prp file: %s", args[0]);
		return -1;
	}

	if (cfg_load_env(cfg) == -1 ||
			cfg_load_str(cfg, instr, instr + 100) == -1) {
		AMSG("");
		return -1;
	}
	i = 1;
	if (cfg_vget_int(cfg, &i, 500, TEXT("mail.folder.%d.idx"), i) == -1) {
		AMSG("");
		return -1;
	}
	if (i != 2) {
		PMSG("mail.folder.1.idx == %d", i);
		return -1;
	}

	cfg_del(cfg);
	tcase_printf(verbose, "done");

    return 0;
}
