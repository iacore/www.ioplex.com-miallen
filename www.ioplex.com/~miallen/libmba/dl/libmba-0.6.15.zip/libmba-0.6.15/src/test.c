#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

/* Just for tcase tests. Otherwise dlopened code cannot resolve this
 * symbol
 */

int
tcase_printf(int verbose, const char *fmt, ...)
{
	int ret = 0;

	if (verbose) {
		va_list ap;
		va_start(ap, fmt);
		ret = vprintf(fmt, ap);
		va_end(ap);
	} else {
		fmt = NULL;
	}

	return ret;
}

