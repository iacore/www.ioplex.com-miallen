/* pool - a container of recycleable objects
 * Copyright (c) 2002 Michael B. Allen <mballen@erols.com>
 *
 * The MIT License
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */ 

#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include "mba/msgno.h"
#include "mba/iterator.h"
#include "mba/stack.h"
#include "mba/pool.h"
#include "defines.h"

struct pool {
	void *(*new_data)(void *);
	void (*free_data)(void *);
	void *arg;
	char *bitmap;
	unsigned int max_size;
	unsigned int unused;
	struct stack *list;
};

struct pool *
pool_new(unsigned int max_size,
			void *(*new_data_fn)(void *), void *arg,
			void (*free_data_fn)(void *))
{
	struct pool *p;

	if (new_data_fn == NULL) {
		errno = EINVAL;
		PMNO(errno);
		return NULL;
	}

	if (max_size == 0 || max_size > POOL_SIZE_MAX) {
		max_size = POOL_SIZE_MAX;
	}
	if ((p = malloc(sizeof *p)) == NULL ||
			(p->bitmap = calloc(max_size / 8 + 1, 1)) == NULL ||
			(p->list = stack_new(max_size)) == NULL) {
		PMNO(errno);
		if (p) {
			free(p->bitmap);
			free(p);
		}
		return NULL;
	}
	p->new_data = new_data_fn;
	p->free_data = free_data_fn;
	p->arg = arg;
	p->max_size = max_size;
	p->unused = 0;

	return p;
}
void
pool_del(void *p)
{
	if (p) {
		struct pool *po = p;
		stack_del(po->list, po->free_data);
		free(po->bitmap);
		free(po);
	}
}
void *
pool_get(struct pool *p)
{
	unsigned int i, lim, b, n;

	if (p == NULL) {
		errno = EINVAL;
		PMNO(errno);
		return NULL;
	}
	if (p->unused == 0 && stack_size(p->list) == p->max_size) {
		errno = ERANGE;
		PMNO(errno);
		return NULL;
	}

	lim = p->max_size / 8 + 1;
	for (i = 0, n = 0; i < lim; i++) {
		b = p->bitmap[i] & 0xFF;
		if (b != 0xFF) {
			void *data;

			b = ~b;
			b = b & -(int)b;
			switch (b) {
				case 1: n = 0; break;
				case 2: n = 1; break;
				case 4: n = 2; break;
				case 8: n = 3; break;
				case 16: n = 4; break;
				case 32: n = 5; break;
				case 64: n = 6; break;
				case 128: n = 7; break;
			}
			n += i * 8;

			if (n == p->max_size) {
				errno = ERANGE;
				PMNO(errno);
				return NULL;
			} else if ((n == stack_size(p->list))) {
				if ((data = p->new_data(p->arg)) == NULL) {
					errno = ENOMEM;
					PMNO(errno);
					return NULL;
				}
				if (stack_push(p->list, data) == -1) {
					AMSG("");
					p->free_data(data);
					return NULL;
				}
			} else {
				if ((data = stack_get(p->list, n)) == NULL) {
					AMSG("");
					return NULL;
				}
				p->unused--;
			}
			p->bitmap[i] |= b;
			return data;
		}
	}

	return NULL;
}
int
pool_release(struct pool *p, void *data)
{
	if (p && data) {
		void *d;
		unsigned int n, i;
		iter_t iter;

		stack_iterate(p->list, &iter);
		for (n = 0; (d = stack_next(p->list, &iter)) != NULL; n++) {
			if (d == data) {
				i = n / 8;
				n = n - (i * 8);
				p->bitmap[i] &= ~(1 << n);
				p->unused++;
				return 0;
			}
		}
	}

	errno = EINVAL;
	PMNO(errno);

	return -1;
}
unsigned int
pool_size(struct pool *p)
{
	return p == NULL ? 0 : stack_size(p->list);
}
unsigned int
pool_unused(struct pool *p)
{
	return p == NULL ? 0 : p->unused;
}
void
pool_iterate(void *this, iter_t *iter)
{
	struct pool *p = this;
	if (p) {
		stack_iterate(p->list, iter);
	}
}
void *
pool_next(void *this, iter_t *iter)
{
	struct pool *p = this;
	return stack_next(p->list, iter);
}

