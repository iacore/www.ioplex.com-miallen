#ifndef VARRAY_H
#define VARRAY_H

/* varray - a variable sized array
 */ 

#include <stddef.h>
#include <mba/iterator.h>

struct varray;

struct varray *varray_new(size_t membsize);
void varray_del(void *va);
void varray_release(struct varray *va, unsigned int from);
void *varray_get(struct varray *va, unsigned int idx);
void varray_iterate(void *va, iter_t *iter);
void *varray_next(void *va, iter_t *iter);

#endif /* VARRAY_H */
