#ifndef HEXDUMP_H
#define HEXDUMP_H

/* hexdump - print hexdump of memory to stream
 */

#include <stdio.h>

void hexdump(FILE *stream, const void *src, size_t n, size_t width);
const char *mbstoax(const char *src, size_t sn, int wn);

#endif /* HEXDUMP_H */

