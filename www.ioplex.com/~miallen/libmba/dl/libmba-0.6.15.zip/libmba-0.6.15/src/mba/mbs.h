#ifndef MBS_H
#define MBS_H

/* mbs - locale dependent multi-byte string functions
 */

#include <stddef.h>
#include <wchar.h>

int mbslen(const char *src);
int mbsnlen(const char *src, size_t sn, int cn);

size_t mbssize(const char *src);
size_t mbsnsize(const char *src, size_t sn, int cn);

char *mbsdup(const char *src);
char *mbsndup(const char *src, size_t n, int cn);

char *mbsoff(char *src, int off);
char *mbsnoff(char *src, int off, size_t sn);

char *mbschr(char *src, wchar_t wc);
char *mbsnchr(char *src, size_t sn, int cn, wchar_t wc);

int mbswidth(const char *src, size_t sn, int wn);

char *mbssub(char *src, size_t sn, int wn);

#endif /* MBS_H */
