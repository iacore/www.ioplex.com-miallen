#include "common.h"
#include "mba/hashmap.h"

int
HashmapExercise(int verbose, struct cfg *cfg, char *args[])
{
	struct hashmap *h;
    int rate, i, n = 0;
	char *str;
	cfg = NULL; args[0] = NULL;

    if ((h = hashmap_new(HASHMAP_MEDIUM, hash_string, NULL, free)) == NULL) {
		AMSG("");
		return -1;
	}

	rate = EXERCISE_R0;
	for (i = 0; i < EXERCISE_MED_COUNT; i++) {
		if (i == EXERCISE_MED_P1) {
			rate = EXERCISE_R1;
		} else if (i == EXERCISE_MED_P2) {
			rate = EXERCISE_R2;
		} else if (i == EXERCISE_MED_P3) {
			rate = EXERCISE_R3;
		}

		if (rand() % 10 < rate) {
	        str = malloc(8);
	        sprintf(str, "%07d", n++);
	        if (hashmap_put(h, str, str) == -1) {
				AMSG("");
				return -1;
			} else {
	 	      	tcase_printf(verbose, "put  %s %d\n", str, hashmap_size(h));
			}
		} else {
			if (hashmap_is_empty(h)) {
				tcase_printf(verbose, "hashmap empty\n");
			} else {
				iter_t iter;
				hashmap_iterate(h, &iter);
		        str = hashmap_next(h, &iter);
				if (str) {
					str = hashmap_get(h, str);
	    	    	tcase_printf(verbose, "get %s %d\n", str, hashmap_size(h));
					if ((str = hashmap_remove(h, str)) == NULL) {
						errno = EFAULT;
						PMNO(errno);
						return -1;
					}
					tcase_printf(verbose, "remove %s %d\n", str, hashmap_size(h));
					free(str);
				} else {
					tcase_printf(verbose, "nothing left to iterate over\n");
				}
			}
		}
    }

	hashmap_del(h);

    return 0;
}
