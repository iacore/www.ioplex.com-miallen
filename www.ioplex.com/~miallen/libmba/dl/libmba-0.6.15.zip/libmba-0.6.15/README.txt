libmba
A library of generic C modules
http://www.ioplex.com/~miallen/libmba/

Mon Aug 25 15:02:44 EDT 2003

There have been significant and pervasive changes however to emphasize that
all of these changes are binary compatible I have not incremented the major
version  number.  All  code  that  uses  the published interfaces of libmba
should work without modification.

The  most  significant  change  is  the  addition  of  src/mba/text.h which
contains  many  macros  that abstract wide and multi-byte string functions.
Depending  on  whether  or  not  USE_WCHAR  is defined the string functions
defined  in text.h will accept wide or multi-byte strings. This will permit
programs  to  run  using  wide  character or local dependent multibyte text
behavior.  Some  of  the  libmba modules such as cfg have been converted to
support  both  wide and local dependent multi-byte text using the new tchar
typedef. Do not be alarmed that these prototypes have changed. Because this
typedef  is  defined as either unsigned char or wchar_t you can continue to
use these modules without using tchar at all. If however you choose to take
advantage of this new I18N functionality please read the following document
for important information:

  http://www.ioplex.com/~miallen/libmba/dl/docs/ref/text_details.html

The  test suite has been cleaned up considerably. Just run make followed by
the generated tmba program in the tcase directory to run all tests.

The  build  process  has  been formalized further. The code is now compiled
using  -D_XOPEN_SOURCE=500  meaning  SUSv2/UNIX98 but most of the code does
not  require  this  standards  level.  In  fact  #ifdefs have been added to
consider lesser environments although they have not been thoroughly tested.

Finally,  a path module has been introduced. Currently this module contains
one  function; path_canon which canonicalizes a pathname. The state machine
design  is  very  safe  when  given  the full range of possible inputs (see
tcase/tests/data/PathCanonExamples.data). 

Sat May 17 16:30:37 EDT 2003

Multiple bugs have been fixed in the csv module.

Mon May  5 23:44:43 EDT 2003

There have been siginificant bugs fixed and changes.

The  iterate  and  next  functions of the linkedlist, cfg (now documented),
hashmap,  pool,  stack,  and  varray  modules  now  accept an iter_t object
defined  in  new  mba/iterator.h  header to hold the state of an iteration.
These  modules  now  permit  multiple  iterators  per  object and are fully
reentrant.

The library has been profiled with ccmalloc. Several memory leaks have been
detected and repaired. The shellout module was not freeing the struct sho *
in  sho_close.  The  linkedlist_insert_sorted function (now documented) did
not  free  a  struct  entry  * if it was the first element and the replaced
parameter  was  specified.  The  cfg_store  function did not close the file
pointer  it  opened.  The cfg_del function did not delete the struct cfg *.
The  linkedlist_remove_last  function did not free the struct node * if the
list contained only one element. 

The  linkedlist_get  function  has  been  optimized  for forward-sequential
access  (an  O(1) operation now whereas previously it was O(log N)). It may
also be faster for non-sequential access altough it will likely be slightly
slower  for  reverse-sequential access. A small cache of 2 elements is used
to save pointers recently accessed elements. The cache is adjustable with a
change  to  the source but 2 elements is probably optimal because it covers
the case of two nested iterators.

The  linkedlist_insert_sorted  function has been reviewed and documented as
an  official  part  of  the linkedlist interface. As mentioned previously a
memory leak in that function was found and fixed. 

Tue Apr 29 16:08:21 EDT 2003

A  csv module has been added. This module properly parses the CSV format in
that  it  can  handle  quoted elementes, quotes within quoted elements, and
commas  and  quotes  withing  quotes.  It should be able to handle anything
exported by Excel or Gnumeric (but don't quote me on that :-) 

Tue Apr  1 19:18:39 EST 2003

The  varray  module did not zero out the array pointing to allocated memory
chunks.  This  could  lead  to dereferencing an invalid pointer. The bug is
fixed in this release. 

Sat Mar 22 04:51:01 EST 2003

libmba-0.5.0 released

This  release introduces the varray module which is a "variable array" that
dynamically allocates storage in increasingly larger chunks are elements of
an index are accessed. The documentation has also been improved. 

Fri Dec 20 00:30:32 EST 2002

libmba-0.4.7 released

A  pool module has been added for reusing objects that are costly to create
like large buffers, database connections, etc. 

Sat Nov 23 01:16:43 EST 2002

libmba-0.4.6 released

A  symbol  was  left  out of the MSVC .def file and a mailing list has been
established for questions, suggestions, and patches. 

Sat Nov 16 17:53:42 EST 2002

libmba-0.4.5 released

A  cfg  module  for  loading  and  storing properties files has been added,
portability  has  been  improved,  and the web page, API reference, and man
pages  are  now  generated  with  the CStyleX package. There have also been
numerous other small adjustments to the code. 

--

INSTALLATION

The domnode module requires Expat which, if you do not already have it, may
be obtained here: 

  http://www.libexpat.org/

Provided  Expat  is  installed  properly,  building  the source should be a
matter of editing the 'prefix' line in the Makefile and running: 

  # make install

If  you  do  not require the domnode module you can take it out of the OBJS
line  in  the Makefile. Or if you only require a select module, some can be
extracted  from  the  package without too much work. The intra-dependencies
are: 

  MODULE     NEEDS
  -----------------------------------
  cfg        msgno linkedlist
  csv        msgno
  domnode    msgno linkedlist stack
  hashmap    msgno linkedlist
  hexdump
  linkedlist msgno
  mbs        msgno
  msgno
  profile          linkedlist hashmap
  stack      msgno
  pool       msgno stack
  varray

But  msgno  can easily be dissolved with dummy macros by just including the
msgno.h header directly and not defining the MSGNO macro. 

On  other  platforms it may only be necessary to adjust src/defines.h. With
everything  turned off in defines.h the code is ANSI although natrually all
possible combinations have not been tested. 

To compile the domnode module with i18n support, it is necessary to install
the encdec library: 

  http://www.ioplex.com/~miallen/encdec/

edit  src/defines.h  to  set  HAVE_ENCDEC  1, add -lencdec to the $(SONAME)
target, and rebuild. 

>>IMPORTANT<<
The  msgno  module is disabled by default. To activate it, define the MSGNO
macro before including the msgno.h header or set it with a -DMSGNO compiler
flag. 

See README.win32 regarding Windows installation.

