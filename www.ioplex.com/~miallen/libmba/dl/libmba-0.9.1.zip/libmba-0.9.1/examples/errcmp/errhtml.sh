#!/bin/sh

# 1 + N * 2

csvprint -s '\t' /tmp/out.csv "<tr><td>%0<td>%1<td>%2<td>%3<td>%4<td>%5<td>%6<td>%7<td>%8<td>%9<td>%10<td>%11<td>%12<td>%13<td>%14<td>%15<td>%16<td>%17<td>%18<td>%19<td>%20<td>%21\n"
