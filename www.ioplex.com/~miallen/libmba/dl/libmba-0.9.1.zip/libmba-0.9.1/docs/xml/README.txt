Just a rough parent/child relationship hierarchy.

desc|ret|title|th|td|li|a|p|pre|small|i|b|tt|def|ident|blockquote|h2
    ident
    def
    p
    tt
    pre
    example
        title
        desc
    table
        title
        tr
            th|td
    tablenum
    examplenum
    br
    a
    blockquote
    ul
        li
    i
    b
    small
    h2
    link

meth|func
    pre
    param
    desc
    ret

code
    title
        ident
    pre
    desc

interface
    comments
    include
    title
        ident
    desc
    group
        title
            ident
        desc
        meth
        code

proj
    title
    short
    desc
    links
        a
    news
        entry
            title
            sub
            desc

library
    title
    desc
    #comment

subtopic
    title
    desc
    group
        title
        desc

