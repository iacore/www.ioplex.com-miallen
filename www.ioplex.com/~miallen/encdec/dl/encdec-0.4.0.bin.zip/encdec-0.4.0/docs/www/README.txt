Tip: If you make the following link this webpage will work locally.

 ln -s ../.. dl

